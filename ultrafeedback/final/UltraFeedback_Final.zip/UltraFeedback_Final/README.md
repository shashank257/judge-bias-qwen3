# UltraFeedback final results | DSC261 Group 3

This release covers 500 frozen UltraFeedback prompts, four candidate answers per prompt, and six Qwen3 judge configurations (0.6B, 1.7B and 4B, thinking off/on).

**Report team:** read [the PDF](report/DSC261_G3_UltraFeedback_Final.pdf) or copy the editable text from [REPORT.md](results/REPORT.md). The H3 estimate and intervals are in results/pooled_h3.csv. Use results/paired_comparisons.csv for matched model/mode differences. Drift is a fraction in the CSV and is multiplied by 100 in the report. Each prompt contributes up to six observations. Preserve prompt clustering in the combined report.

**Replay published results on CPU:** extract this ZIP, install the dependencies with `python -m pip install -r requirements.txt`, then open REPRODUCE_RESULTS.ipynb and run all cells, or run `python reproduce.py`. The notebook also runs on Colab CPU. It recomputes tournament outcomes from 500 frozen inputs and the saved decisions, rebuilds the tables and figures, and checks the published numerical outputs. No Drive account, GPU or inference credentials are required for replay.

**Run model inference:** open inference/RUN_SIX_MODES_COLAB.ipynb in Colab, select a GPU, mount Drive and follow the notebook instructions. The input package and pilot are embedded. Kaggle alternatives and their required frozen .bin input are under inference/. The combined Kaggle notebook covers the original 1.7B/4B thinking-on assignment only. Other Kaggle notebooks are earlier operational variants. Use the six-mode Colab notebook to schedule the whole final-study scope. Regeneration uses stochastic decoding. Exact reproduction of the observed analysis uses the CPU notebook.

**Files and provenance**
- results/: contents of the completed six-mode Colab export, including compact decisions for all modes, recorded attempts, environment summary, checkpoint inventory, figures, original analysis code, and the 500 prompts and candidate ratings.
- code/: frozen experiment helpers and prompt templates. inference/ANALYZE_SIX_MODES.ipynb reruns the original checkpoint analysis when the full Drive checkpoint tree is mounted.
- checkpoints/: both available Kaggle checkpoint snapshots in their original importable ZIP format. pilot/: original and recovered pilot event logs and parser audit. The final Drive export contains compact decisions and attempt metadata for every mode. Full generated text for the additional Colab-only batches remains in the experiment owner's Drive. Neither that private Drive tree nor model weights are required for CPU replay.
- report/: final PDF and its rendering source (optional dependency: reportlab). results/analysis_cell.py retains the original Colab export logic. Source attribution and model revisions appear in results/manifest.json. MANIFEST_SHA256.json records archive-member checksums.

The original strict parser influenced the pilot retries. Full-study generation uses the consistent A/B parser. Report the 475 new prompts as a sensitivity analysis. Unresolved verdicts remain missing. GPT-4 fine-grained scores supply the reference. Human agreement and controlled format interventions are evaluated in other parts of the team repository.
